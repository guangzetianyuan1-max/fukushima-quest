<?php
/**
 * Plugin Name: Hima Counter
 * Description: ひまなぶた のゲームの数を数える（ダウンロード＝ホーム画面のアイコンから初めて開いた端末／クリック＝サイトのボタンを押した端末）。同じ端末は1回だけ。
 * Version: 1.0.0
 * Author: ひまなぶた
 */
// 10/10 本人「ホームページ上でアプリのダウンロード数、ゲームクリック数のカウンターを設置して欲しい。同じアカウントからの重複はカウントしない」
// ・ゲームにアカウントは無い＝端末（ブラウザ）ごとに作った ランダムな番号（UUID）で 重複を はぶく（個人を 特定する 情報は 持たない）
// ・水増しの 防ぎ＝同じ IP からの 新しい 番号は 1日に 種類ごと 5つまで（IP は 一時的な 合図（transient）の 鍵に ハッシュで 使うだけ・保存しない）
// ・POST /wp-json/hima/v1/hit {kind:"install"|"click", id:"<uuid>"} ／ GET /wp-json/hima/v1/counts → {install, click}
if (!defined('ABSPATH')) exit;

function hima_counter_table() { global $wpdb; return $wpdb->prefix . 'hima_hits'; }

register_activation_hook(__FILE__, function () {
    global $wpdb;
    $t = hima_counter_table();
    $c = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE $t (
        kind varchar(16) NOT NULL,
        vid char(36) NOT NULL,
        created datetime NOT NULL,
        PRIMARY KEY  (kind, vid)
    ) $c;");
});

add_action('rest_api_init', function () {
    register_rest_route('hima/v1', '/hit', array(
        'methods' => 'POST',
        'permission_callback' => '__return_true',
        'callback' => function (WP_REST_Request $r) {
            global $wpdb;
            $p = $r->get_json_params();
            if (!is_array($p)) $p = json_decode($r->get_body(), true);   // sendBeacon は text/plain で 送る
            $kind = isset($p['kind']) ? $p['kind'] : '';
            $id = isset($p['id']) ? strtolower($p['id']) : '';
            if (!in_array($kind, array('install', 'click'), true)) return new WP_REST_Response(array('ok' => false), 400);
            if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $id)) return new WP_REST_Response(array('ok' => false), 400);
            $t = hima_counter_table();
            if ($wpdb->get_var($wpdb->prepare("SELECT 1 FROM $t WHERE kind=%s AND vid=%s", $kind, $id))) return array('ok' => true, 'new' => false);
            $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
            $key = 'hima_ip_' . $kind . '_' . substr(hash('sha256', $ip . wp_salt('nonce')), 0, 20);
            $n = (int) get_transient($key);
            if ($n >= 5) return array('ok' => true, 'new' => false, 'limited' => true);
            set_transient($key, $n + 1, DAY_IN_SECONDS);
            $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $t (kind, vid, created) VALUES (%s, %s, %s)", $kind, $id, current_time('mysql', true)));
            return array('ok' => true, 'new' => true);
        },
    ));
    register_rest_route('hima/v1', '/counts', array(
        'methods' => 'GET',
        'permission_callback' => '__return_true',
        'callback' => function () {
            global $wpdb;
            $t = hima_counter_table();
            $rows = $wpdb->get_results("SELECT kind, COUNT(*) n FROM $t GROUP BY kind", ARRAY_A);
            $out = array('install' => 0, 'click' => 0);
            foreach ((array) $rows as $row) $out[$row['kind']] = (int) $row['n'];
            $res = new WP_REST_Response($out);
            $res->header('Cache-Control', 'no-store');
            return $res;
        },
    ));
});
